// CONVERT C SOURCE CODE TO HTML WITH
// SYNTAX COLORS. SEE STYLE.TXT

#include "ez.h"

text source_code=0, destiny_code=0,
  destiny_p=0;
text source_file="SOURCE.TXT",
    destiny_file="EXAMPLE.HTML";
char style_name[16];

int write_html_tags=1, write_style_classes=1,
  code_box_color=0xFFFFFF, code_text_color=0x000000,
  code_box_border=2, code_box_border_color=0xCCCCCC,
  code_padding_x, code_padding_y;
char code_box_w[8]="728px", code_box_h[8]="auto",
  code_box_border_style[8]="solid";

text c_keywords[]={
  "auto", "break", "case", "char", "const",
  "continue", "default", "define", "do",
  "double", "else", "enum", "elif", "endif",
  "extern", "float", "for", "goto", "if",
  "ifdef", "ifndef", "include", "int", "long",
  "register", "return", "short", "signed",
  "sizeof", "static", "struct", "switch",
  "typedef", "uint", "union", "unsigned",
  "void", "volatile", "while",
  "and", "or", "not", "text", "structure",
  "byte", "ibyte", "uint2", "ushort", "word",
  "int", "uint", "dword", "color", "intq",
  "uintq", "ARRAY", "BOX", "IMAGE", "FONT",
  "object", "event", "ende", "event_any",
  "event_create", "event_draw", "event_input",
  "event_timer", "event_exit"
};

#define N_C_KEYWORDS 65

int is_c_keyword(char *name) {
  for (int i=0; i<N_C_KEYWORDS; i++)
    if (text_equal(name, c_keywords[i]))
      return i;
  return -1;
}

void write_html_c(char c) {
  text p=destiny_p;
  if (c==0x0D)
    p=text_copy(p, "<br>\r\n");
  else if (c==0x0A)
    ;
  else if (c=='>')
    p=text_copy(p, "&gt;");
  else if (c=='<')
    p=text_copy(p, "&lt;");
  else
    *p++=c;
  destiny_p=p;
}

void write_html(text t) {
  while (*t)
    *destiny_p++=*t++;
}

void write_style(text name) {
  char s[64];
  sprintf(s, "<span class='%s'>", name);
  write_html(s);
}
    
void end_style() {
  write_html("</span>");
}

int code_2_html() {
  int i, c, n;
  text p=source_code, q;
  char s[256];
  sprintf(s, \
    "<pre style=\"background: #%06X; color: #%06X;\r\n" \
    "width: %s; height: %s; border: %dpx %s #%06X;\r\n" \
    "overflow: auto; padding: .2em .2em;\">\r\n", code_box_color,
    code_text_color, code_box_w, code_box_h, code_box_border,
    code_box_border_style, code_box_border_color);
  write_html(s);
  write_style("code");
  n=text_n(p);
  for (; *p; p++) {
    c=*p;
    if (!c)
      break;
    if (c==' ' or c=='\t') { // space
      write_html(" ");
      continue;
    }
    if (c==0x0D) { // return
      p++;
      write_html("<br>");
      continue;
    }
    if (c=='>' or c=='<') {
      write_style("symbol");
      if (c=='>')
        write_html("&gt;");
      else
        write_html("&lt;");
      end_style();
      continue;
    }
    if (c=='/') { // comment?
      if (p[1]=='/') { // single
        write_style("comment");
        for (; *p and !is_return(*p); p++)
          write_html_c(*p);
        if (*(p-1))
          p--;
        end_style();
        continue;
      }
      else if (p[1]=='*') { // multi
        write_style("comment");
        for (; *p; p++) {
          if (*p==0xD) {
            write_html("<br>");
            p++;
            continue;
          }
          write_html_c(*p);
          if (*p=='/' and *(p-1)=='*')
            break;
        }
        end_style();
        continue;
      }
    }
    if (c=='"' or c=='\'') { // "string" or 'c'?
      char quote=c;
      write_style("string");
      write_html_c(quote);
      // until return
      for (p++; *p and !is_return(*p); p++) {
        write_html_c(*p);
        // if end quote (and not escape \x)
        if (*p==quote and *(p-1)!='\\')
          break;
      }
      end_style();
      continue;
    }
    if ((is(c, C_SYMBOL) and c!='_')
      or c=='!') { // !@#$%
      write_style("symbol");
      write_html_c(c);
      end_style();
      continue;
    }
    if (is(c, C_NUMBER)) { // 123
      write_style("number");
      for (; *p and !is_end(*p); p++)
        write_html_c(*p);
      end_style();
      p--;
      continue;
    }
    if (is(c, C_ALPHA) or c=='_') { // name
      for (q=s; *p and !is_end(*p)
        and *p!='!'; p++)
        *q++=*p;
      *q=0;
      if (is_c_keyword(s)==-1)
        write_style("code");
      else
        write_style("keyword");
      write_html(s);
      end_style();
      p--;
      continue;
    }
    write_style("code");
    write_html_c(c);
    end_style();
  }
  write_html("</span>\r\n");
  write_html("</pre>\r\n\r\n");
  return 1;
}

int create_html() {
  text p;
  if (write_html_tags) {
    write_html("<html>\r\n" \
      "<head><title></title></head>\r\n" \
      "<body bgcolor=\"#000000\">\r\n\r\n");
    write_style("title");
    write_html("TITLE");
    end_style();
    write_html("\r\n<br><br>\r\n");
    write_html("<a name='x'>\r\n");
    write_style("text");
    write_html("Description.");
    end_style();
    write_html("\r\n<br>\r\n");
  }
  if (write_style_classes) {
    if (!(p=load_text("STYLE.TXT")))
      return 0;
    write_html(p);
    destroy(p);
  }
  code_2_html();
  if (write_html_tags)
    write_html("</body>\r\n</html>");
  return 1;
}

int main() {
  if (!(source_code=load_text(source_file))) {
    printf("Error loading SOURCE.TXT\n\n");
    getch();
    return 0;
  }
  if (!allocate(text, destiny_code, 256*KB))
    return 0;
  *destiny_code=0, destiny_p=destiny_code;
  create_html();
  save_text(destiny_file, destiny_code);
  printf("Created %s\n\n", destiny_file);
  destroy(destiny_code);
  system(destiny_file);
  getch();
  return 0;
}