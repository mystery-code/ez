#define INTERFACE
#include "ez.h"

FONT font1;

char *message=
  "The Quick Brown\r\n" \
  "Fox Jumps Over\r\n" \
  "The Lazy Dog",
  *alphabet=
  "0123456789ABCDEFGHI\r\n" \
  "JKLMNOPQRSTUVWXYZab\r\n" \
  "cdefghijklmnopqrstu\r\n" \
  "vwxyz_ .?;:'\",~!@#$\r\n" \
  "%^&*()[]{}=+-<>/\\|`";

event_create
  create_screen(416, 384);
  load_font(&font1,
    "..\\..\\media\\font\\code3.bmp");
  set_title("Custom Font");
ende

event_draw
  BOX box;
  clear_screen(BABY_BLUE);
  set_font_c(&font1, WHITE);
  draw_text(message, screen_w/2-
    text_w(message)/2, 40);
  make_text_box(alphabet, &box);
  align_box(&box, &screen_box, CENTER);
  box.y=screen_h-box.h-8;
  draw_gradient('v', 'a', box.x, box.y,
    box.w, box.h, POWER_BLUE, BABY_BLUE);
  draw_box(box.x, box.y, box.w, box.h,
    WHITE, 0);
  set_font_c(&font1, WHITE);
  draw_text(alphabet, box.x+inset_x,
    box.y+inset_y);
  set_font_c(&main_font, WHITE);
  draw_title();
ende

event_input
  // ...
ende