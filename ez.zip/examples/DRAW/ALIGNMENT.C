#define INTERFACE
#include "ez.h"

text title="Interface Alignment";

event_create
  create_screen(768, 512);
  set_screen_color(BLACK);
  set_title(title);
ende

event_draw
  int h;
  char a[256];
  BOX box, panel1, panel2, panel3;
  set_font_color(WHITE);
  h=font.h+inset_h;
  set_box(&panel1, 0, h,
    screen_w, h+font.h);
  draw_shade(&panel1, 'v', BLACK, RED);
  set_box(&panel2, 0, panel1.y+panel1.h,
    font.w*12, screen_h-(panel1.y+panel1.h));
  draw_shade(&panel2, 'v', BLACK, GREEN);
  set_box(&panel3, panel2.w, panel1.y+
    panel1.h, screen_w-panel2.w,
    screen_h-panel1.h-h);
  draw_shade(&panel3, 'v', BLACK, BLUE);
  set_box(&box, panel1.x, panel1.y,
    panel1.w/2, panel1.h);
  draw_box_o(&box, WHITE);
  draw_text_a("R.West", &box, CENTER);
  move_box_r(&box);
  draw_box_o(&box, WHITE);
  draw_text_a("R.East", &box, CENTER);
  set_box(&box, panel2.x, panel2.y,
    panel2.w, panel2.h/3);
  draw_box_o(&box, WHITE);
  draw_text_a("G.North", &box, CENTER);  
  move_box_d(&box);
  draw_box_o(&box, WHITE);
  draw_text_a("G.Center", &box, CENTER); 
  move_box_d(&box);
  draw_box_o(&box, WHITE);
  draw_text_a("G.South", &box, CENTER);
  set_box(&box, panel2.w, panel1.y+panel1.h,
    screen_w-panel2.w, panel1.h);
  draw_box_o(&box, WHITE);
  draw_text_a("B.North", &box, CENTER);  
  set_box(&box, panel3.x,
    panel3.y+panel1.h, panel3.w/3,
    screen_h-(panel1.h*3)-h);
  draw_box_o(&box, WHITE);
  draw_text_a("B.West", &box, CENTER);
  move_box_r(&box);
  draw_box_o(&box, WHITE);
  draw_text_a("B.Center", &box, CENTER);
  move_box_r(&box);
  draw_box_o(&box, WHITE);
  draw_text_a("B.East", &box, CENTER);
  set_box(&box, panel3.x, screen_h-panel1.h,
    panel3.w/2, panel1.h);
  draw_box_o(&box, WHITE);
  draw_text_a("B.South.West", &box, CENTER);
  move_box_r(&box);
  draw_box_o(&box, WHITE);
  draw_text_a("B.South.East", &box, CENTER);
ende

event_input
  // ...
ende