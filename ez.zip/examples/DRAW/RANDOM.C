#define INTERFACE
#define TIMER
#include "ez.h"

event_create
  create_screen(512, 384);
  set_timer(500);
  set_title("Random Graphics");
ende

event_draw
  int i, x, y, w, h, c, type;
  clear_screen(BLACK);
  for (i=0; i<100; i++) {
    x=random_n(-screen_w, screen_w);
    y=random_n(-screen_h, screen_h);
    w=random_n(64, screen_w);
    h=random_n(64, screen_h);
    c=rgb(random(255), random(255), random(255));
    type=random(3);
    if (type==0)
      draw_box(x, y, w, h, c, random(1));
    else if (type==1)
      draw_ellipse(x, y, 64, 64, c);
    else if (type==2)
      fill_ellipse(x, y, 64, 64, c);
  }
  draw_title();
ende

event_input
  // ...
ende

event_timer
  redraw();
ende