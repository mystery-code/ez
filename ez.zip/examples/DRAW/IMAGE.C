#define INTERFACE
#include "ez.h"

IMAGE i1;

event_create
  create_screen(512, 512+36);
  load_bmp(&i1, "space.bmp");
  set_title("Draw Image");
ende

event_draw
  move_image(&i1, 0, title_box.h);
  draw_image(&i1);
ende

event_input
  input_title();
ende