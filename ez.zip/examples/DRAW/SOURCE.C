#define INTERFACE
#include "ez.h"

FONT font1;

char *source_code=0;

event_create
  create_screen(512, 400);
  source_code=load_text("source.txt");
  set_title("Draw Source Code");
  load_font(&font1,
    "..\\..\\media\\font\\code1.bmp");
ende

event_draw
  clear_screen(WHITE);
  set_font(&font1);
  set_font_color(BLACK);
  draw_code(source_code, 16, 40);
  draw_title();
ende

event_input
  input_title();
ende