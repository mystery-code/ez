#define INTERFACE
#include "ez.h"

event_create
  create_screen(1024, 576);
  set_title("Graphics Demonstration: " \
    "Gradients");
ende

event_draw
  int x, y, w, h;
  BOX box;
  copy_box(&box, &title_box);
  w=(screen_w/2);
  h=((screen_h-box.h)/2);
  draw_gradient('v', 'a', 0, box.h, w, h,
    RED, BLUE);
  draw_gradient('v', 'a', w, box.h, w, h,
    POWER_BLUE, BABY_BLUE);
  draw_gradient('v', 'a', 0, h+box.h, w, h,
    RED_ROSE, YELLOW);
  draw_gradient('v', 'a', w, h+box.h, w, h,
    LIME_GREEN, SKY_BLUE);
  draw_bevel(w/2, h/2+box.h, w, h,
    WHITE, PASTEL_PINK, 0, 0);
  w=screen_w/7, h=(screen_h-box.h)/6;
  x=(screen_w/2)-(w/2);
  y=(screen_h/2)-(h/2)+(box.h/2);
  fill_ellipse(x, y, w, h, BEACH_BLUE);
  draw_ellipse(x, y, w, h, WHITE);
ende

event_input
  input_title();
ende