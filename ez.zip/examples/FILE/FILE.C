// MINIMAL FILE I/O EXAMPLE (NO ERROR
// CHECKING FOR CLARIY)

#include "ez.h"

char t[32];
text name="EXAMPLE.TXT",
  message="Created by FILE.C";

int main() {
  int size=text_n(message);
  create_file(name);
  write_file(message, size);
  close_file();
  open_file(name);
  read_file(t, size);
  close_file();
  puts(t);
  system(name);
  getch();
  return 0;
}