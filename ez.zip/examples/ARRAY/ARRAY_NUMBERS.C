// DYNAMIC ARRAY OF NUMBERS

#include "ez.h"

#define N_ELEMENTS 5

ARRAY array;

int numbers[N_ELEMENTS]={ 1, 2, 3, 4, 5 };

int create_array() {
  int i;
  array_create(&array, sizeof(int));
  for (i=0; i<N_ELEMENTS; i++)
    if (!array_attach(&array, &numbers[i]))
      return 0;
  return 1;
}

void array_display(ARRAY *a) {
  int i, *p;
  for (i=0; i<a->n; i++) {
    p=(int *) array_index(a, i);
    printf("%d ", *p);
  }
}

int main() {
  create_array();
  array_display(&array);
  array_destroy(&array);
  getch();
  return 0;
}