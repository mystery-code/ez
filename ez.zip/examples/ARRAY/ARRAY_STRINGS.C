// DYNAMIC ARRAY OF STRINGS

#include "ez.h"

#define N_COLORS 8
#define NAME_SIZE 32

ARRAY array;

char strings[N_COLORS][NAME_SIZE]={
  "BLACK", "WHITE", "RED", "GREEN", "BLUE",
  "CYAN", "MAGENTA", "YELLOW"
};

void array_display(ARRAY *a) {
  int i;
  char *p;
  for (i=0; i<a->n; i++) {
    p=(char *) array_index(a, i);
    printf("%s\n", p);
  }
}

int main() {
  int i;
  array_create(&array, NAME_SIZE);
  for (i=0; i<N_COLORS; i++)
    array_attach(&array, strings[i]);
  array_sort_s(&array);
  array_display(&array);
  array_destroy(&array);
  getch();
  return 0;
}