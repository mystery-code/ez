// DYNAMIC ARRAY OF STRUCTURES/OBJECTS

#include "ez.h"

#define N_USERS 50
#define NAME_SIZE 64

#define N_MALE_NAMES 22
#define N_FEMALE_NAMES 22

object {
  char name[NAME_SIZE];
  int age, gender, race,
    height, weight;
} USER;

ARRAY users;

char male_names[N_MALE_NAMES][NAME_SIZE]={
  "Andy", "Bob", "Brian", "Chris", "Dan", "Eric",
  "Joe", "John", "Keith", "Ken", "Leon", "Mike",
  "Nate", "Pete", "Randy", "Robert", "Sean",
  "Timothy", "Vince", "Walter", "Xavier", "Zack"
};

char female_names[N_FEMALE_NAMES][NAME_SIZE]={
  "Ann", "Alisha", "Ashley", "Betty", "Brandy",
  "Christina", "Deanne", "Donna", "Ellen",
  "Elisa", "Jane", "Kimberly", "Keisha", "Lisa",
  "Mary", "Pamela", "Rose", "Sue", "Teresa",
  "Victoria", "Wendy", "Yolanda"
};

#define N_RACES 12

text race_names[N_RACES]={
  "European", "African", "Indian", "Asian",
  "Chinese", "Japanese", "Spanish", "Hawaiian",
  "Arabian", "Jewish", "Mixed", "Albino"
};

int ascend=1;
enum { BY_NAME, BY_AGE };

int create_user(char *name, int age, int gender,
  int race, int height, int weight) {
  USER *p;
  if (!(p=(USER *) array_expand(&users)))
    return 0;
  strcpy(p->name, name);
  p->age=age, p->gender=gender, p->race=race;
  p->height=height, p->weight=weight;
}

int create_users() {
  int i, n, age, gender,
    race, height, weight;
  char *name;
  array_create(&users, sizeof(USER));
  for (i=0; i<N_USERS; i++) {
    gender=random(2);
    if (gender) {
      n=random(N_MALE_NAMES-1);
      name=male_names[n];
      height=random_n(165, 175);
      weight=random_n(130, 230);
    }
    else {
      n=random(N_FEMALE_NAMES-1);
      name=female_names[n];
      height=random_n(160, 170);
      weight=random_n(100, 175);
    }
    age=random_n(13, 75);
    race=random(N_RACES-1);
    create_user(name, age, gender,
      race, height, weight);
  }
  return 1;
}

void destroy_users() {
  array_destroy(&users);
}

int by_name(const void *a, const void *b) {
  USER *p=(USER *) a, *q=(USER *) b, *z;
  if (!ascend)
    z=p, p=q, q=z;
  return strcmp(p->name, q->name);
}

int by_age(const void *a, const void *b) {
  USER *p=(USER *) a, *q=(USER *) b, *z;
  if (!ascend)
    z=p, p=q, q=z;
  return (p->age)-(q->age);
}

void arrange_users(int by, int as) {
  ARRAY *a=&users;
  int (*fp)(const void *,
    const void *);
  ascend=as;
  if (by==BY_NAME)
    fp=by_name;
  else if (by==BY_AGE)
    fp=by_age;
  qsort(a->p, a->n, a->size, fp);
}

void display_users() {
  int i;
  USER *p;
  for (i=0; i<users.n; i++) {
    p=(USER *) array_index(&users, i);
    printf("* User: %s. %d/%c. %s. " \
      "%dCM, %dLBs\n", p->name, p->age,
      p->gender ? 'M':'F', race_names[p->race],
      p->height, p->weight);
  }
}

int main() {
  if (!create_users()) {
    printf("Error creating users");
    return 0;
  }
  arrange_users(BY_NAME, 1);
  display_users();
  destroy_users();
  getch();
  return 0;
}