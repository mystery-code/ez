///////////// MOS 6502 DISASSEMBLER //////////////

#define DEFAULT_FILE "TEST.BIN"
#define DESTINY_SIZE 16*1024

#include "ez.h"
#include "6502.h"
#include "disassemble.h"

//////////////////////////////////////////////////

int main(int n, char **av) {
  text p;
  char name[256]=DEFAULT_FILE;
  if (n>1)
    strcpy(name, av[1]);
  if (!allocate(text, destiny, DESTINY_SIZE)) {
    error("Memory allocation failed\n");
    goto end_main;
  }
  if (!disassemble_file(name)) {
    error("Error loading file\n");
    goto end_main;
  }
  printf("MOS 6502 Disassembler: %s\n\n", name);
  printf("%s\n", destiny);
  p=strrchr(name, '.');
  if (p)
    *p=0;
  strcat(p, ".txt");
  save_file(name, destiny, strlen(destiny));
  p=strrchr(name, "\\");
  if (p)
    p++;
  printf("\nSuccess. Size = %u bytes. " \
    "See: %s\n", file_size, name);
  // ...
  end_main:
  destroy(source_p);
  destroy(destiny_p);
  getch();
  return 0;
}

int disassemble_instruction() {
  uint n, x, b, c, m,
    id, size, opcode;
  int i, destiny_start=destiny_c;
  char name[64];
  b=*source&0xFF;
  opcode_type=mode=0;
  name[0]=0;
  size=1;
  c=(b>>5)&7, m=(b>>2)&7, id=b&3;
  high=(b>>4)&0xF, low=b&0xF;

  put("%04X  %02X ", ip, *source&0xFF);
  i=identify_opcode(b);
  if (i==I_NONE) {
    put("       Invalid", b);
    size=1;
    goto comment;
  }
  strcpy(name, instruction_names[i]);
  opcode=opcode_type;
  if (opcode==OT_ONE) {
    put("       %s", instruction_names
      [one_opcodes[one_opcode_i].name]);
    size=1;
    goto comment;
  }
  if (opcode==OT_BRANCH) {
    if (!(i==I_JSR or i==I_JMP)) {
      n=(source[1]&0xFF);
      put("%02X     b%s $%04X", n,
        condition_names[c], ip+n+2);
      size=2;
      goto comment;
    }
    n=((source[1]&0xFF))|((source[2]&0xFF)<<8);
    put("%02X %02X  ", source[1]&0xFF, source[2]&0xFF);
    if (i==I_JSR)
      put("jsr $%04X", n);
    else if (i==I_JMP) {
      if (b==0x6C)
        put("jmp ($%04X)", n);
      else
        put("jmp $%04X", n);
    }
    size=3;
    goto comment;
  }
  if (opcode==OT_SHIFT) {
    x=(b>>5)&3;
    strcpy(name, shift_names[x]);
    get_mode_shift(m);
    goto end_dasm;
  }
  if (opcode==OT_ARITHMETIC) {
    strcpy(name, basic_names[opcode_index]);
    get_mode_basic(m);
    goto end_dasm;
  }  
  if (i==I_LDA or i==I_STA)
    get_mode_basic(m);
  else if (i==I_LDX or i==I_LDY)
    get_mode_ldx_ldy(m);
  else if (i==I_STX or i==I_STY)
    get_mode_stx_sty(m);
  else if (i==I_CPX or i==I_CPY)
    get_mode_cpx_cpy(m);
  else if (i==I_INC or i==I_DEC)
    get_mode_inc_dec(m);
  else if (i==I_JSR) {
    mode=AM_ABSOLUTE;
  }
  else if (i==I_JMP) {
    if (high==4)
      mode=AM_ABSOLUTE;
    else
      mode=AM_INDIRECT;
  }
  else if (i==I_BIT) {
    if (b==0x24)
      mode=AM_ZERO;
    else
      mode=AM_ABSOLUTE;
  }
  end_dasm:
  size=2;
  if (mode==0)
    size=1;
  if (mode==AM_ABSOLUTE or mode==AM_ABSOLUTE_X
    or mode==AM_ABSOLUTE_Y or mode==AM_INDIRECT)
    size=3;

  n=source[1]&0xFF;
  b=source[2]&0xFF;
  x=b<<8|n;
  if (size==2)
    put("%02X     ", n);
  else if (size==3)
    put("%02X %02X  ", n, b);
  put("%s ", name);

  if (mode==AM_ACCUMULATOR)
    put("a");
  else if (mode==AM_IMMEDIATE)
    put("#$%02X", n);
  else if (mode==AM_ZERO)
    put("$%02X", n);
  else if (mode==AM_ZERO_X)
    put("$%02X,x", n);
  else if (mode==AM_ZERO_Y)
    put("$%02X,y", n);
  else if (mode==AM_ABSOLUTE)
    put("$%04X", x);
  else if (mode==AM_ABSOLUTE_X)
    put("$%04X,x", x);
  else if (mode==AM_ABSOLUTE_Y)
    put("$%04X,y", x);
  else if (mode==AM_INDIRECT_X)
    put("($%02X,x)", n);
  else if (mode==AM_INDIRECT_Y)
    put("($%02X),y", n);
  else if (mode==AM_INDIRECT)
    put("($%04X)", x);
  else if (mode==AM_RELATIVE)
    put("($%04X)", x);

  comment:
  n=destiny_c-destiny_start;
  for (i=n; i<=30; i++)
    put(" ");
  put("; %s", opcode_type_names[opcode_type]);
  puts("");
  return size;
}