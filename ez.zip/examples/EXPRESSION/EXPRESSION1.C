// EVALUATE CONSTANT EXPRESSION

#include <stdio.h>
#include <stdlib.h>

#define EXAMPLE "1+(2*3)+4"

#define and &&
#define or ||

#define isa(c) ((c>='A' and c<='Z') \
 or (c>='a' and c<='z') or c=='_')
#define isn(c) (c<='9' and c>='0')
enum { NAME, NUMBER, SYMBOL };

int error_n;
#define error(why) \
 printf("\nError: %s\n\n", why), error_n++

char *stream=EXAMPLE, token[256],
 type, last_type, value, depth;

int next();
void term(int *), factor(int *), atom(int *);

int main() {
  int v;
  printf("Expression: %s\n", stream);
  error_n=0, depth=0;
  next();
  term(&v);
  if (depth!=0)
    { error("Mismatched ()'s"); return 0; }
  if (!error_n)
    printf("Result: %d\n\n", v);
  getch();
  return 0;
}

// add, subtract

void term(int *v) {
  int rv, c;
  factor(v);
  while ((c=*token)=='+' or c=='-') {
    if (!next())
      { error("Value expected"); return; }
    factor(&rv);
    if (c=='+') (*v)+=rv;
    else if (c=='-') (*v)-=rv;
  }
}

// multiply, divide

void factor(int *v) {
  int rv, c;
  atom(v);
  while ((c=*token)=='*' or c=='/') {
    if (!next())
      { error("Value expected"); return; }
    atom(&rv);
    if (c=='*') (*v)*=rv;
    else if (c=='/') (*v)/=rv;
  }
}

// get value

void atom(int *v) {
  if (error_n)
   return;
  if (*token=='(') {
    next();
    term(v);
    if (*token!=')')
      { error(") expected"); return; }
    next();
  }
  else {
    next();
    *v=value;
  }
}

// copy token and advance

int next() {
  int i;
  last_type=type;

  while (*stream==' ' or
    *stream=='\t') stream++;
  if (!*stream) return 0;
  if (*stream=='(') depth++;
  if (*stream==')') depth--;

  if (isa(*stream)) {        // NAME
    for (i=0; isn(*stream);
     token[i++]=*stream++);
    token[i]=0;
    type=NAME;
    return 1;
  }
  if (isn(*stream)) {        // NUMBER
    for (i=0; isn(*stream);
     token[i++]=*stream++);
    token[i]=0;
    value=atoi(token);
    type=NUMBER;
    return 1;
  }
  token[0]=*stream++;        // SYMBOL
  token[1]=0;
  type=SYMBOL;
  return 1;
}