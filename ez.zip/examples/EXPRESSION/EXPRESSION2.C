/* Convert standard infix expression to RPN
then to ASM. Supports names, numbers, symbols.
RPN may be optimized */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define and &&
#define or ||

#define isa(c) ((c>='A' and c<='Z') or \
  (c>='a' and c<='z') or c=='_')
#define isn(c) (c<='9' and c>='0')
enum { NAME=1, NUMBER, SYMBOL };

char *source="(1+2)*(3-4)+5", destiny[512];
char t[256], token[256];

int get_token(), evaluate(), generate();
void level1(), level2(), level3(),
  level4(), level5();
 
#define descend(x) get_token(); x()
#define output() sprintf(t, "%s ", token),\
  strcat(destiny, t)
#define outputc() sprintf(t, "%c ", c),\
  strcat(destiny, t)

int token_type, symbol, depth;

char *symbols[]={ "&", "|", "<<", ">>",
  "+", "-", "*", "/" };

char *registers[]={ "eax", "ecx", "edx",
  "ebx", "esi", "edi" };
int c_register=0;

int main() {
  printf("* Expression: %s\n", source);
  evaluate();
  printf("* Reverse Polish: %s\n", destiny);
  printf("* Assembler:\n\n");
  generate();
  printf("\n");
  getch();
  return 0;
}

// display error then exit

char *errors[]={ "None", "Syntax error", 
  "Value expected", "Mismatched parenthesis",
  "Expression too complex" };

enum { SE_NONE, SE_SYNTAX, SE_VALUE,
  SE_MISMATCH, SE_COMPLEX };

void error(int n) {
  printf("\n* Error: %s\n\n", errors[n]);
  exit(0);
}

// copy token and advance. skip whitespace first

int get_token() {
  int i;
  for (; *source==' ' or
    *source=='\t'; source++);
  if (!*source)
    return 0;
  if (isn(*source)) {
    for (i=0; isn(*source);
      token[i++]=*source++);
    token[i]=0; 
    return token_type=NUMBER;;
  }
  if (isa(*source)) {
    for (i=0; isa(*source);
      token[i++]=*source++);
    token[i]=0;
    return token_type=NAME;
  }
  token[0]=*source++, token[1]=0;
  symbol=token[0];
  return token_type=SYMBOL;
}

// convert expression

int evaluate() {
  c_register=depth=0;
  get_token();
  level1();
  if (depth) {
    error(SE_MISMATCH);
    return 0;
  }
  return 1;
}

// bitwise AND, OR, XOR

void level1() {
  int c;
  level2();
  while ((c=token[0])=='&' or
    c =='|' or c=='^') {
    descend(level2);
    outputc();
  }
}

// shifts

void level2() {
  int c, c2;
  level3();
  while (((c=token[0])=='<' and
    (c2=*source)=='<') or ((c=token[0])=='>'
    and (c2=*source)=='>')) {
    source++;
    descend(level3);
    outputc();
  }
}

// add or subtract

void level3() {
  int c;
  level4();
  while ((c=token[0])=='+' or c=='-') {
    descend(level4);
    outputc();
  }
}

// multiply or divide

void level4() {
  int c;
  level5();
  while ((c=token[0])=='*' or
    c=='/' or c=='%') {
    descend(level5);
    outputc();
  }
}

// parentheses or get value

void level5() {
  if (token[0]=='(') {
    depth++;
    get_token();
    level1();
    if (token[0]!=')')
      error(SE_MISMATCH);
    depth--;
    get_token();
  }
  else {
    output();
    if (token_type==SYMBOL)
      error(SE_VALUE);
    get_token();
  }
}

#define operation(name) printf("%s %s, %s\n",\
  name, registers[c_register-1],\
  registers[c_register])

// convert expression in destiny to ASM

int generate() {
  int i, c, c2;
  source=destiny;
  if (!get_token())
    return 0;
  printf("mov %s, %s\n",
    registers[c_register++], token);

  while (get_token()) {
    if (token_type==NUMBER) {
      printf("mov %s, %s\n",
        registers[c_register++], token);
      if (c_register>=5)
        error(SE_COMPLEX);
    }
    else if (token_type==SYMBOL) {
      c=token[0], c2=token[1];
      c_register--;
      if (c=='+')
        operation("add");
      else if (c=='-')
        operation("sub");
      else if (c=='&')
        operation("and");
      else if (c=='|')
        operation("or");
      else if (c=='<' and c2=='<')
        operation("shl");
      else if (c=='>' and c2=='>')
        operation("shr");
      else if (c=='*')
        operation("imul");
      else if (c=='/') {
        if (c_register==1) // eax/ecx
          printf("cdq\nidiv ecx\n");
        else if (c_register==2) { // ecx/edx
          printf("push eax\n");
          printf("mov eax, ecx\nmov ecx, edx\n");
          printf("cdq\nidiv ecx\nmov ecx, eax\n");
          printf("pop eax\n");
        }
        else
          error(SE_COMPLEX);
      }
      else
        error(SE_SYNTAX);        
    }
    else
      error(SE_SYNTAX);
  }
  return 1;
}