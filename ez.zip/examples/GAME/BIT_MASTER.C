#define GAME
#include "ez.h"

int WINDOW_W=360, WINDOW_H=492;

text t[256], title_t="Bit-Master: %hh";

text help_t=
 "Fun Game for Programmers.\r\n" \
 "Click BITs. Count in binary.\r\n" \
 "Match the decimal number\r\n" \
 "in the red box to make rows\r\n" \
 "disappear. Press any key.\r\n" \
 "r=Reset. p=Pause. Esc=exit";

text pause_t=
 "Paused. Press p to continue\r\n" \
 "or r=Reset. Esc=exit";

text game_over_t=
 "Game over. Score: %hh.\r\n" \
 "Press any key";

int scene, score;

enum { SCENE_TITLE, SCENE_PLAY,
 SCENE_PAUSE, SCENE_GAME_OVER };
enum { EASY=4000, NORMAL=2500, HARD=1000 };

BOX board, my_box;

uint my_n, red_n, magic_n=0xAD,
  cbit_x, cbit_y, bits_h,
  BIT_W=32, BIT_H=48;

byte my_numbers[8+4], red_numbers[8+4];

IMAGE bits_i, bit1_i, bit0_i, close_i;

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

int load_images() {
  if (!load_font(&main_font,
    "../../media/font/code1.bmp"))
    return 0;
  set_font_color(WHITE);
  if (!load_bmp(&bits_i, "image/bits.bmp"))
    return 0;
  if (!load_bmp(&bit1_i, "image/1.bmp"))
    return 0;
  if (!load_bmp(&bit0_i, "image/0.bmp"))
    return 0;
  if (!load_bmp(&close_i, "image/x.bmp"))
    return 0;
  return 1;
}

int random_byte() {
  int n;
  again:
  n=random_n(1, 3);
  if (n<2)
    n=random(16);
  else if (n==2)
    n=random(128);
  else if (n==3)
    n=random(255);
  if (!n or text_find(red_numbers, n))
    goto again;
  return n;
}

void reset_game() {
  int i;
  score=0, bits_h=1, cbit_x=cbit_y=0;
  memory_zero(my_numbers, 12);
  memory_zero(red_numbers, 12);
  for (i=0; i<8; i++)
    red_numbers[i]=random_byte();
  set_box(&board, 4, 70, BIT_W*8, BIT_H*8);
  scene=SCENE_TITLE;
}

void remove_byte(text t, int i) {
  int n, j;
  text p, q;
  if (i!=7) {
    p=&t[i], q=&p[1], n=7-i;
    for (j=0; j<n; j++, *p++=*q++);
  }
  my_numbers[7]=0;
  red_numbers[7]=random_byte();
}

void remove_row(int i) {
  remove_byte(my_numbers, i);
  remove_byte(red_numbers, i);
  bits_h--;
  if (bits_h<1)
    bits_h=1;
}

int check_numbers() {
  int i;
  for (i=0; i<8; i++) {
    if (my_numbers[i]==red_numbers[i]) {
      score+=my_numbers[i];
      remove_row(i);
      return 1;
    }    
  }
  return 0;
}

void draw_board() {
  int i, n, x, y, w, h;
  char t[64];
  draw_image_at(&bits_i, 4, 35);
  draw_image_at(&bits_i, 4, 457);
  w=32, h=48;
  for (y=0; y<8; y++) {
    for (x=0; x<8; x++) {
      set_box(&my_box, (x*w)+board.x,
        (y*h)+board.y, w, h);
      draw_box_b(&my_box, WHITE, 1);
      draw_box_b(&my_box, GRAY, 0);
    }
    set_box(&my_box, (x*w)+board.x,
      (y*h)+board.y, 48, h);
    draw_box_o(&my_box, WHITE);
    my_box.x+=48;
    draw_box_o(&my_box, RED);
    if (y>=8-bits_h) {
      my_n=my_numbers[7-y];
      red_n=red_numbers[7-y];
      u2t(my_n, t);
      my_box.x-=40, my_box.y+=11;
      draw_text(t, my_box.x, my_box.y);
      my_box.x+=44;
      u2t(red_n, t);
      draw_text(t, my_box.x, my_box.y);
    }
  }
}

void draw_bit(int n, int x, int y) {
  draw_image_at(n ? &bit1_i:&bit0_i, x, y);
}

void draw_byte(int n, int x, int y) {
  int i;
  for (i=8; i>0; i--, x+=BIT_W)
    draw_bit((n>>(i-1))&1, x, y);
}

void draw_my_numbers() {
  int i, y=404;
  for (i=0; i<bits_h; i++, y-=BIT_H)
    draw_byte(my_numbers[i], 4, y);
}

void draw_title_scene() {
  draw_text(help_t, 16, 130);
  draw_byte(magic_n, 50, 300);
}

void draw_play_scene() {
  draw_board();
  draw_my_numbers();
}

void draw_pause_scene() {
  draw_text(pause_t, 16, 130);
  draw_byte(magic_n, 50, 300);
}

void draw_game_over() {
  char t[256];
  print(t, game_over_t, score);
  draw_text(t, 44, 170);
  draw_byte(magic_n, 50, 300);
}

///////////////////// EVENTS /////////////////////

event_timer
  if (scene!=SCENE_PLAY or mouse_1)
    return 1;
  if (bits_h<8)
    bits_h++;
  else
    scene=SCENE_GAME_OVER;
  redraw();
ende
  
event_create
  create_screen(WINDOW_W, WINDOW_H);
  set_timer(NORMAL);
  load_images();
  reset_game();
ende

event_draw
  char t[128];
  clear_screen(BLACK);
  print(t, title_t, score);
  draw_text(t, 8, 4);
  draw_image_at(&close_i, 324, 4);
  draw_box(0, 0, screen_w-1,
    screen_h-1, GRAY, 0);
  if (scene==SCENE_TITLE)
    draw_title_scene();
  else if (scene==SCENE_PLAY)
    draw_play_scene();
  else if (scene==SCENE_PAUSE)
    draw_pause_scene();
  else if (scene==SCENE_GAME_OVER)
    draw_game_over();
ende

event_input
  if (event_key_c) {
    if (scene==SCENE_TITLE)
      scene=SCENE_PLAY;
    else if (scene==SCENE_GAME_OVER
      or key=='r')
      reset_game();
    else if (key=='p') {
      if (scene==SCENE_PLAY)
       	scene=SCENE_PAUSE;
      else if (scene==SCENE_PAUSE)
	      scene=SCENE_PLAY;
    }
    goto _draw;
  }
  else if (event_mouse) {
    cbit_x=(mouse_x-board.x)/BIT_W;
    cbit_y=(mouse_y-board.y)/BIT_H;
    if (mouse_type=='c') {
      if (select_box(&board))
        my_numbers[7-cbit_y]^=
          (1<<(7-cbit_x));
      if (select_image(&close_i))
        exit();
      if (scene!=SCENE_PLAY) {
        reset_game();
        scene=SCENE_PLAY;
      }
    }
    else if (mouse_type=='r')
      check_numbers();
    _draw:
    redraw();
  }
ende