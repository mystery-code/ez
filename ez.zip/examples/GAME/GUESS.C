// GUESS THE NUMBER

#include <stdio.h>
#include <stdlib.h>

int main() {
  int n, guess=0, tries=1;
  printf("I'm thinking of a number, 1-100\n");
  srand(time(0));
  n=(rand()%99)+1;
  while (n!=guess) {
    printf("Enter your guess:\n");
    scanf("%d", &guess);
    if (guess>n)
      printf("Too high\n");
    else if (guess<n)
      printf("Too low\n");
    else
      break;
    tries++;
  }
  printf("Correct! It was %d.\n", n);
  printf("You guessed in %d tries.\n", tries);
  getch();
  return 0;
}